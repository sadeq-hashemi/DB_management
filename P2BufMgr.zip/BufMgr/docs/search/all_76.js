var searchData=
[
  ['valid',['valid',['../classbadgerdb_1_1_bad_buffer_exception.html#a8c008149b0e598d906b3bbc865e23107',1,'badgerdb::BadBufferException']]]
];
